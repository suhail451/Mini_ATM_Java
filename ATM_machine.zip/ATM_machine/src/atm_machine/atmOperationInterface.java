/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_machine;

/**
 *
 * @author arain
 */
public interface atmOperationInterface {
    
    public void view_balane();
    public void withdraw_amout(double withdraw_amount);
    public void deposit_amout(double deposit_amount);
    public void view_miniStatement();
    
}
