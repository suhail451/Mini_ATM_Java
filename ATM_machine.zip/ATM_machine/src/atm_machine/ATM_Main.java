/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_machine;

import java.util.Scanner;

/**
 *
 * @author arain
 */
public class ATM_Main {
    public static void main(String[] args) {
        
        atmOperationInterface op = new ATM_Implementation() {};
        Atm atm=new Atm();
        int atm_no=1234;
        int atm_pin=123;
        System.out.println("Welcome to my Atm machine!");
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Print Atm no :");
        atm_no=sc.nextInt();
       

        System.out.println("Enter User pin :");
        int user_pin1=sc.nextInt();
        
        if((atm_no==1234)&&(atm_pin==user_pin1)){
            System.out.println("Validation successful");
            boolean state=true;
            while(state){
                System.out.println(" \n ");
                System.out.println("Choose the Operation you want to perform ");
                System.out.println(" \n ");
                System.out.println(" 1 Availabel balance \n 2 deposit amount \n 3 withdraw amount \n 4 chck history \n 5 exit");
                System.out.println(" \n ");
                System.out.print(" : ");
                int ch=sc.nextInt();
                if(ch==1){
                    
                  
                    op.view_balane();
                }
                else if (ch==2){
                    System.out.println("Enter Amount Deposit :");
                    double depositAmount=sc.nextDouble();
                    op.deposit_amout(depositAmount);
                }
                else if(ch==3){
                    System.out.println("Enter the Amount you want to withdraw");
                    double withdrawAmount=sc.nextDouble();
                    
                    op.withdraw_amout(withdrawAmount);
                }
                
                else if(ch==4){
                    op.view_miniStatement();
                }
                else if(ch==5){
                 state=false;
                    System.out.println(" Collect your atm card \n Thank you for using our Atm ; ");
                }
                else {
                    System.out.println("ENTER CORRECT CHOICE");}
            }

        }else {System.out.println("Sorry error");}
         
         System.out.println("hy");
        
        
      
        
    }
    
}
