/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_machine;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author arain
 */
public class ATM_Implementation implements atmOperationInterface {

     Atm atm=new Atm();
     Map<Double,String>ministmnt=new HashMap<>(); 
    @Override
    public void view_balane() {
        System.out.print("Your balance is :");
        System.out.println(atm.getBalance());
    }

    @Override
    public void deposit_amout(double deposit_amount) {
        ministmnt.put(deposit_amount, "Amount Deposited");
        System.out.println(deposit_amount+"Deposited Successfuly");
        
        atm.setBalance(atm.getBalance()+deposit_amount);
    }
    
    @Override
    public void withdraw_amout(double withdraw_amount) {
        
        System.out.println(withdraw_amount+"Withdraw successfuly");
        if(withdraw_amount > atm.getBalance()){
            System.out.println("Sorry you do not have sufficent balance to withdraw");}
        else{
            ministmnt.put(withdraw_amount,"Amount withdrawn");
        atm.setBalance(atm.getBalance()-withdraw_amount);}
    }

    @Override
    public void view_miniStatement() {
        for(Map.Entry<Double,String> m:ministmnt.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        
        }
        
        }
    
}
