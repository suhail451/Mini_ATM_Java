/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_machine;

/**
 *
 * @author arain
 */
public class Atm {
    
    private  double balance;
    private double deposit_ammount;
    private double withdraw_amount;
    
    
    
    public Atm(){
    
    
    
    }  

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getDeposit_ammount() {
        return deposit_ammount;
    }

    public void setDeposit_ammount(double deposit_ammount) {
        this.deposit_ammount = deposit_ammount;
    }

    public double getWithdraw_amount() {
        return withdraw_amount;
    }

    public void setWithdraw_amount(double withdraw_amount) {
        this.withdraw_amount = withdraw_amount;
    }
    
    
    
}
